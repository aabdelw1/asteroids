import math

num = 2.377124124123523452
rounded = round(num,2)

print(float(rounded))