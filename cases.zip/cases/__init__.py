from .case1 import params as case1_params
from .case2 import params as case2_params
from .case3 import params as case3_params
from .case4 import params as case4_params
from .case5 import params as case5_params
from .case6 import params as case6_params
from .case7 import params as case7_params
from .case8 import params as case8_params


index = { 1: case1_params,
          2: case2_params,
          3: case3_params,
          4: case4_params,
          5: case5_params,
          6: case6_params,
          7: case7_params,
          8: case8_params }
